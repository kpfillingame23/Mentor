
import React, { useState } from 'react';
import { MentorMode } from '../types';
import { BookOpen, Wind, Compass, ArrowRight } from 'lucide-react';

interface ModeSelectorProps {
  onSelect: (mode: MentorMode, name: string) => void;
}

const ModeSelector: React.FC<ModeSelectorProps> = ({ onSelect }) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSelect = (mode: MentorMode) => {
    if (!name.trim()) {
      setError('Please enter your name first.');
      return;
    }
    onSelect(mode, name.trim());
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#f2e8da]">
      <div className="max-w-4xl w-full space-y-12 text-center">
        <div className="space-y-4">
          <h1 className="text-6xl font-light text-[#5d5245] tracking-tight">Mentor</h1>
          <p className="text-xl text-[#8c7e6d] font-light italic">“Grow, learn, and reflect.”</p>
        </div>

        <div className="max-w-md mx-auto space-y-4">
          <label className="block text-sm font-medium text-[#8c7e6d] text-left">What should I call you?</label>
          <input
            type="text"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (error) setError('');
            }}
            placeholder="Enter your name..."
            className="w-full px-5 py-4 rounded-2xl border border-[#d9cfc1] bg-white/80 focus:bg-white focus:ring-2 focus:ring-[#a68a64] focus:border-transparent outline-none transition-all text-[#5d5245] shadow-sm"
          />
          {error && <p className="text-red-500 text-sm text-left font-medium">{error}</p>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <button
            onClick={() => handleSelect(MentorMode.STUDY)}
            className="group p-8 rounded-[2.5rem] bg-[#6495ED] border border-[#4a90e2] hover:shadow-2xl hover:-translate-y-1 transition-all text-left space-y-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center text-[#6495ED] shadow-lg group-hover:scale-110 transition-transform">
              <BookOpen size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-semibold text-white">Study Aid</h3>
              <p className="text-sm text-blue-50 mt-2 leading-relaxed">Structured learning and subject-focused help with your Wise Owl.</p>
            </div>
            <div className="flex items-center text-white font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
              Start Session <ArrowRight size={18} className="ml-2" />
            </div>
          </button>

          <button
            onClick={() => handleSelect(MentorMode.CALM)}
            className="group p-8 rounded-[2.5rem] bg-[#879267] border border-[#5e6737] hover:shadow-2xl hover:-translate-y-1 transition-all text-left space-y-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-[#f5f5dc] flex items-center justify-center text-[#879267] shadow-lg group-hover:scale-110 transition-transform">
              <Wind size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-semibold text-[#f5f5dc]">Calm Aid</h3>
              <p className="text-sm text-[#d4d9c1] mt-2 leading-relaxed">Emotional support and grounding with your Gentle Deer.</p>
            </div>
            <div className="flex items-center text-[#f5f5dc] font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
              Start Session <ArrowRight size={18} className="ml-2" />
            </div>
          </button>

          <button
            onClick={() => handleSelect(MentorMode.EXPLORE)}
            className="group p-8 rounded-[2.5rem] bg-[#F97316] border border-[#EA580C] hover:shadow-2xl hover:-translate-y-1 transition-all text-left space-y-4"
          >
            <div className="w-14 h-14 rounded-2xl bg-[#FFEDD5] flex items-center justify-center text-[#F97316] shadow-lg group-hover:scale-110 transition-transform">
              <Compass size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-semibold text-[#FFEDD5]">Explore</h3>
              <p className="text-sm text-[#FFEDD5]/80 mt-2 leading-relaxed">Open discussion and curiosity with your Clever Fox.</p>
            </div>
            <div className="flex items-center text-[#FFEDD5] font-bold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
              Start Session <ArrowRight size={18} className="ml-2" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ModeSelector;
