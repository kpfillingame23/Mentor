
import React, { useState, useRef, useEffect } from 'react';
import { MentorMode, Message } from '../types';
import { THEMES, CHARACTER_LIMIT } from '../constants';
import { sendMessageStream } from '../services/geminiService';
import Avatar from './Avatar';
import { ArrowLeft, Send, Loader2 } from 'lucide-react';

interface ChatInterfaceProps {
  mode: MentorMode;
  userName: string;
  onBack: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ mode, userName, onBack }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const theme = THEMES[mode];
  
  // Modes with colored backgrounds
  const isStudyMode = mode === MentorMode.STUDY;
  const isCalmMode = mode === MentorMode.CALM;
  const isExploreMode = mode === MentorMode.EXPLORE;
  const isColoredMode = isStudyMode || isCalmMode || isExploreMode;

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const greetings = {
      [MentorMode.STUDY]: `Hoot! Hello ${userName}. I'm your Study Owl. Ready to learn something new? I can help explain complex topics or even make some flashcards for you!`,
      [MentorMode.CALM]: `Hello ${userName}... I'm your Calm Deer Mentor. I'm here to listen and help you find your center. How are you feeling right now?`,
      [MentorMode.EXPLORE]: `Hi ${userName}! I'm your Explore Fox. I'm so curious to hear what's on your mind! Shall we explore a new idea together?`
    };
    
    setMessages([{
      id: 'initial',
      role: 'model',
      text: greetings[mode],
      timestamp: Date.now()
    }]);
  }, [mode, userName]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input.trim(),
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const mentorMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: mentorMsgId,
      role: 'model',
      text: '',
      timestamp: Date.now()
    }]);

    let fullResponse = '';
    try {
      const stream = sendMessageStream(mode, userName, messages, userMsg.text);
      for await (const chunk of stream) {
        fullResponse += chunk;
        setMessages(prev => prev.map(m => 
          m.id === mentorMsgId ? { ...m, text: fullResponse } : m
        ));
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper for header/input background colors
  const getHeaderBg = () => {
    if (isStudyMode) return 'bg-[#6495ED]/90 border-white/20';
    if (isCalmMode) return 'bg-[#879267]/90 border-white/20';
    if (isExploreMode) return 'bg-[#F97316]/90 border-white/20';
    return 'bg-white/90 border-black/5';
  };

  const getHeaderTextColor = () => {
    if (isColoredMode) return 'text-white';
    return theme.text;
  };

  const getSubTextColor = () => {
    if (isStudyMode) return 'text-blue-100';
    if (isCalmMode) return 'text-[#d4d9c1]';
    if (isExploreMode) return 'text-[#FFEDD5]/80';
    return 'text-gray-400';
  };

  const getInputStyles = () => {
    if (isColoredMode) {
      return 'bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:bg-white/20';
    }
    return 'bg-white border-black/10 text-gray-800 focus:border-black/20';
  };

  const getSendButtonStyles = () => {
    if (!input.trim() || isLoading) {
      return isColoredMode ? 'bg-white/10 text-white/30 cursor-not-allowed' : 'bg-gray-100 text-gray-400 cursor-not-allowed';
    }
    if (isStudyMode) return 'bg-white text-[#6495ED] hover:scale-105 active:scale-95 shadow-lg';
    if (isCalmMode) return 'bg-[#f5f5dc] text-[#879267] hover:scale-105 active:scale-95 shadow-lg';
    if (isExploreMode) return 'bg-[#FFEDD5] text-[#F97316] hover:scale-105 active:scale-95 shadow-lg';
    return 'bg-black text-white hover:scale-105 active:scale-95 shadow-md';
  };

  return (
    <div className={`flex flex-col h-screen ${theme.bg} transition-colors duration-500`}>
      {/* Header */}
      <header className={`flex items-center justify-between px-6 py-3 ${getHeaderBg()} backdrop-blur-md border-b z-10 shadow-sm`}>
        <button 
          onClick={onBack}
          className={`p-2 rounded-full transition-colors ${isColoredMode ? 'hover:bg-white/10 text-white' : 'hover:bg-black/5 text-gray-600'}`}
        >
          <ArrowLeft size={20} />
        </button>
        
        <div className="flex items-center space-x-4">
          <Avatar mode={mode} size="sm" />
          <div className="flex flex-col">
            <span className={`text-xs font-bold uppercase tracking-[0.2em] ${getHeaderTextColor()}`}>
              {mode} MENTOR
            </span>
            <span className={`text-[10px] font-medium italic ${getSubTextColor()}`}>Mentor: Thinking Partner</span>
          </div>
        </div>

        <div className="w-10" />
      </header>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar"
      >
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}
            >
              <div className={`
                max-w-[85%] px-5 py-3 rounded-2xl shadow-sm text-sm leading-relaxed whitespace-pre-wrap break-words
                ${msg.role === 'user' ? theme.bubbleUser : theme.bubbleMentor}
              `}>
                {msg.text || (isLoading && msg.role === 'model' && <Loader2 className="animate-spin" size={16} />)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <div className={`p-6 ${getHeaderBg()} backdrop-blur-md border-t`}>
        <div className="max-w-3xl mx-auto relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value.slice(0, CHARACTER_LIMIT))}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Message your ${mode.toLowerCase()} mentor...`}
            className={`w-full pl-5 pr-16 py-4 rounded-2xl border outline-none transition-all resize-none min-h-[60px] max-h-[200px] shadow-inner ${getInputStyles()}`}
            rows={1}
          />
          <div className="absolute right-3 bottom-3 flex items-center space-x-3">
            <span className={`text-[10px] font-medium ${input.length >= CHARACTER_LIMIT ? 'text-red-500' : (isColoredMode ? 'text-white/60' : 'text-gray-400')}`}>
              {input.length}/{CHARACTER_LIMIT}
            </span>
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className={`p-2.5 rounded-xl transition-all ${getSendButtonStyles()}`}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
