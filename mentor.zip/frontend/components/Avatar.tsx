
import React from 'react';
import { MentorMode } from '../types';
import { THEMES } from '../constants';

interface AvatarProps {
  mode: MentorMode;
  size?: 'sm' | 'md' | 'lg';
}

const StudyOwl: React.FC<{ theme: any }> = ({ theme }) => (
  <svg viewBox="0 0 100 100" className="w-full h-full">
    {/* Body - Round Owl */}
    <circle cx="50" cy="55" r="35" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="2" />
    {/* Belly Patch */}
    <ellipse cx="50" cy="65" rx="20" ry="15" fill="white" opacity="0.5" />
    {/* Wings */}
    <path d="M15,55 Q5,55 15,75" fill="none" stroke={theme.eggHint} strokeWidth="3" strokeLinecap="round" />
    <path d="M85,55 Q95,55 85,75" fill="none" stroke={theme.eggHint} strokeWidth="3" strokeLinecap="round" />
    {/* Head Tufts/Ears */}
    <path d="M30,25 L20,15 L40,22" fill={theme.eggHint} />
    <path d="M70,25 L80,15 L60,22" fill={theme.eggHint} />
    {/* Eyes - Big and Wise */}
    <circle cx="38" cy="45" r="12" fill="white" stroke={theme.eggHint} strokeWidth="1" />
    <circle cx="62" cy="45" r="12" fill="white" stroke={theme.eggHint} strokeWidth="1" />
    <circle cx="38" cy="45" r="5" fill={theme.eggHint} />
    <circle cx="62" cy="45" r="5" fill={theme.eggHint} />
    {/* Glasses */}
    <circle cx="38" cy="45" r="14" fill="none" stroke={theme.eggHint} strokeWidth="1" opacity="0.4" />
    <circle cx="62" cy="45" r="14" fill="none" stroke={theme.eggHint} strokeWidth="1" opacity="0.4" />
    <line x1="48" y1="45" x2="52" y2="45" stroke={theme.eggHint} strokeWidth="1" />
    {/* Beak */}
    <path d="M47,55 L50,62 L53,55 Z" fill="#f6ad55" />
  </svg>
);

const CalmDeer: React.FC<{ theme: any }> = ({ theme }) => (
  <svg viewBox="0 0 100 100" className="w-full h-full">
    {/* Body */}
    <ellipse cx="50" cy="70" rx="30" ry="20" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="2" />
    {/* Head */}
    <circle cx="50" cy="40" r="25" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="2" />
    {/* Antlers - Tiny and Cute */}
    <path d="M40,20 Q35,5 25,15" fill="none" stroke={theme.eggHint} strokeWidth="2.5" strokeLinecap="round" />
    <path d="M60,20 Q65,5 75,15" fill="none" stroke={theme.eggHint} strokeWidth="2.5" strokeLinecap="round" />
    {/* Ears */}
    <ellipse cx="28" cy="35" rx="8" ry="4" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="1" transform="rotate(-30 28 35)" />
    <ellipse cx="72" cy="35" rx="8" ry="4" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="1" transform="rotate(30 72 35)" />
    {/* Eyes - Peaceful/Closed */}
    <path d="M38,42 Q42,46 46,42" fill="none" stroke={theme.eggHint} strokeWidth="2" strokeLinecap="round" />
    <path d="M54,42 Q58,46 62,42" fill="none" stroke={theme.eggHint} strokeWidth="2" strokeLinecap="round" />
    {/* Nose */}
    <circle cx="50" cy="50" r="2.5" fill={theme.eggHint} />
    {/* Spots */}
    <circle cx="45" cy="65" r="2" fill="white" opacity="0.6" />
    <circle cx="55" cy="72" r="2" fill="white" opacity="0.6" />
    <circle cx="62" cy="68" r="2" fill="white" opacity="0.6" />
  </svg>
);

const ExploreFox: React.FC<{ theme: any }> = ({ theme }) => (
  <svg viewBox="0 0 100 100" className="w-full h-full">
    {/* Tail */}
    <path d="M70,70 Q95,50 80,30 Q70,40 70,70" fill={theme.eggHint} opacity="0.8" />
    <path d="M80,30 Q75,35 70,40" fill="white" opacity="0.5" />
    {/* Body */}
    <circle cx="50" cy="65" r="28" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="2" />
    {/* Head */}
    <path d="M25,45 Q25,15 50,15 Q75,15 75,45 L50,65 Z" fill={theme.eggMain} stroke={theme.eggHint} strokeWidth="2" />
    {/* Ears - Big and Pointy */}
    <path d="M25,30 L15,5 L40,20 Z" fill={theme.eggHint} />
    <path d="M75,30 L85,5 L60,20 Z" fill={theme.eggHint} />
    {/* White Cheeks */}
    <circle cx="35" cy="45" r="10" fill="white" opacity="0.4" />
    <circle cx="65" cy="45" r="10" fill="white" opacity="0.4" />
    {/* Eyes - Curious Sparkle */}
    <circle cx="40" cy="40" r="4" fill={theme.eggHint} />
    <circle cx="39" cy="38" r="1.5" fill="white" />
    <circle cx="60" cy="40" r="4" fill={theme.eggHint} />
    <circle cx="59" cy="38" r="1.5" fill="white" />
    {/* Nose */}
    <circle cx="50" cy="52" r="3" fill={theme.eggHint} />
  </svg>
);

const Avatar: React.FC<AvatarProps> = ({ mode, size = 'md' }) => {
  const theme = THEMES[mode];
  
  const dimensions = {
    sm: 'w-14 h-14',
    md: 'w-24 h-24',
    lg: 'w-40 h-40'
  };

  const renderMentor = () => {
    switch (mode) {
      case MentorMode.STUDY:
        return <StudyOwl theme={theme} />;
      case MentorMode.CALM:
        return <CalmDeer theme={theme} />;
      case MentorMode.EXPLORE:
        return <ExploreFox theme={theme} />;
      default:
        return null;
    }
  };

  return (
    <div className={`${dimensions[size]} relative flex items-center justify-center drop-shadow-md hover:scale-105 transition-transform duration-300`}>
      {renderMentor()}
    </div>
  );
};

export default Avatar;
