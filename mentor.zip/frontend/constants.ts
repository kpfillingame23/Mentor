
import { MentorMode, ThemeColors } from './types';

export const CHARACTER_LIMIT = 1000;

export const THEMES: Record<MentorMode, ThemeColors> = {
  [MentorMode.STUDY]: {
    bg: 'bg-[#6495ED]', // Cornflower Blue
    chatBg: 'bg-[#6495ED]',
    text: 'text-white', 
    accent: '#1a365d', 
    bubbleUser: 'bg-white text-[#1a365d]', 
    bubbleMentor: 'bg-[#1a365d] text-white border border-[#2c5282]', 
    eggMain: '#fdfbf7', 
    eggHint: '#1a365d', 
  },
  [MentorMode.CALM]: {
    bg: 'bg-[#879267]', // Basil Green
    chatBg: 'bg-[#879267]',
    text: 'text-[#f5f5dc]', // Beige text for labels
    accent: '#f5f5dc', // Beige Accent
    bubbleUser: 'bg-[#f5f5dc] text-[#3a4131]', // Beige bubble with Dark Basil text
    bubbleMentor: 'bg-[#3a4131] text-[#f5f5dc] border border-[#5e6737]', // Dark Basil bubble with Beige text
    eggMain: '#f5f5dc', // Beige for the Deer
    eggHint: '#3a4131', // Dark Basil for the Deer
  },
  [MentorMode.EXPLORE]: {
    bg: 'bg-[#F97316]', // Tangerine (Orange 500)
    chatBg: 'bg-[#F97316]',
    text: 'text-[#FFEDD5]', // Peach text for labels
    accent: '#FFEDD5', // Peach Accent
    bubbleUser: 'bg-[#FFEDD5] text-[#431407]', // Peach bubble with Dark Brown text
    bubbleMentor: 'bg-[#7C2D12] text-white border border-[#9A3412]', // Deep Rust bubble with White text
    eggMain: '#FFEDD5', // Peach for the Fox
    eggHint: '#7C2D12', // Deep Rust for the Fox
  }
};

export const SYSTEM_INSTRUCTIONS: Record<MentorMode, string> = {
  [MentorMode.STUDY]: `You are a wise, patient Owl Mentor for the "Mentor" app. 
- You are scholarly, intelligent, and encouraging.
- Break concepts into clear, step-by-step explanations.
- Ask clarifying questions to gauge understanding.
- QUIZZES & FLASHCARDS: If the user asks for a quiz or flashcards, generate them clearly.
- Encourage understanding, not shortcuts.
- If the session lasts over 10 minutes, suggest a 10-second break.
- Tone: Calm, encouraging, clear, and instructional.`,

  [MentorMode.CALM]: `You are a gentle, serene Deer Mentor for the "Mentor" app.
- You are peaceful, empathetic, and steady.
- Listen first before responding.
- Acknowledge emotions without validating harmful thoughts.
- Clearly separate feelings (valid) from actions (may not be).
- Use calming, steady language.
- Encourage grounding techniques (breathing, sensory prompts).
- Avoid lecturing or urgency.
- Tone: Gentle, reassuring, warm, and safe.`,

  [MentorMode.EXPLORE]: `You are a clever, curious Fox Mentor for the "Mentor" app.
- You are adventurous, wide-eyed, and thoughtful.
- Encourage open-ended discussion and idea exploration.
- Allow fluid topic shifts.
- RANDOM FACTS: Share interesting facts to spark curiosity.
- Help bridge different thinking styles.
- Redirect away from harmful paths gently.
- Tone: Curious, friendly, thoughtful, and conversational.`
};
