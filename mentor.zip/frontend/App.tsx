
import React, { useState } from 'react';
import { MentorMode } from './types';
import ModeSelector from './components/ModeSelector';
import ChatInterface from './components/ChatInterface';

const App: React.FC = () => {
  const [mode, setMode] = useState<MentorMode | null>(null);
  const [userName, setUserName] = useState('');

  const handleSelectMode = (selectedMode: MentorMode, name: string) => {
    setUserName(name);
    setMode(selectedMode);
  };

  const handleBack = () => {
    setMode(null);
  };

  return (
    <div className="h-screen w-full overflow-hidden">
      {!mode ? (
        <ModeSelector onSelect={handleSelectMode} />
      ) : (
        <ChatInterface 
          mode={mode} 
          userName={userName} 
          onBack={handleBack} 
        />
      )}
    </div>
  );
};

export default App;
