
import { GoogleGenAI } from '@google/genai';
import { MentorMode, Message } from '../types';
import { SYSTEM_INSTRUCTIONS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '', vertexai: true });

export async function* sendMessageStream(
  mode: MentorMode,
  userName: string,
  history: Message[],
  newMessage: string
) {
  const systemInstruction = `${SYSTEM_INSTRUCTIONS[mode]}\n\nThe user's name is ${userName}. Address them naturally.`;

  const chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction,
      temperature: 0.7,
    },
  });

  // Convert history to Gemini format
  // Note: We don't send the full history every time in this simple implementation to save tokens,
  // but for a real app, you'd map history to { role, parts: [{ text }] }
  
  try {
    const response = await chat.sendMessageStream({ message: newMessage });
    for await (const chunk of response) {
      yield chunk.text;
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield "I'm sorry, I encountered an error connecting to my thoughts. Please try again.";
  }
}
