
export enum MentorMode {
  STUDY = 'STUDY',
  CALM = 'CALM',
  EXPLORE = 'EXPLORE'
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface UserProfile {
  name: string;
}

export interface ThemeColors {
  bg: string;
  chatBg: string;
  text: string;
  accent: string;
  bubbleUser: string;
  bubbleMentor: string;
  eggMain: string;
  eggHint: string;
}
